#include "FLAME.h"

void time_cubmat( int variant, int nexecs, int print_data, int check_result,
         int size_a, int size_b, int size_c, int size_d, int size_i, int size_j,
         FLA_Obj cb_A, FLA_Obj cb_B, FLA_Obj cb_C, FLA_Obj cb_C_ref_result,
         double * dtime, double * gflops, double * resid );

