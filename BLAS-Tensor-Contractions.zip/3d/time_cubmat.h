#include "FLAME.h"

void time_cubmat( int variant, int nexecs, int matrix_type, 
         int print_data, int check_result,
         int m, int n, int k, int l, FLA_Obj C, FLA_Obj C_copy,
         double * dtime, double * gflops, double * resid );

