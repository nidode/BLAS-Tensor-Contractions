#include "FLAME.h"

void extract_flat_matrix_from_cubic_with_plane_nk(
         int m, int n, int k, FLA_Obj cubmat, int idx, FLA_Obj A );

